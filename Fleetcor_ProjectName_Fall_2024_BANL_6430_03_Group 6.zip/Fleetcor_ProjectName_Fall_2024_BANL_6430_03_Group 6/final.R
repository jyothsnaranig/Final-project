# Load necessary libraries
library(tidyverse)
library(lubridate)
library(caret)
library(ggplot2)

# Assuming your dataset is stored in a CSV file
df <- read.csv("C:/Jyothsna/Jyothsna/DBMS/final project/merged_final_data.csv")

# View the first few rows of the data
head(df)

# Check the structure of the dataset
str(df)

# Convert relevant columns to appropriate types (e.g., dates, factors)
df$YEARMONTH <- as.Date(as.character(df$YEARMONTH), format="%Y%m")
df$CCS_GRADE <- factor(df$CCS_GRADE, levels = c("A", "B", "C1", "C2", "C3", "C4", "D", "F"))
df$QUARTER_REFRESHED <- factor(df$QUARTER_REFRESHED)
df$LOCK_REASON_x <- factor(df$LOCK_REASON_x)

# Create any new variables if necessary
df$TOT_BALANCE <- df$CURRENT_BALANCE + df$UNBILLED_BALANCE

# Summary statistics
summary(df)

# Visualize the distribution of numeric variables
df %>%
  select(PAYDEX, FUEL_NET_REV, NONFUEL_NET_REV, NET_FEE_REV, TOT_NET_REV, PAYMENT_AMOUNT, VANTAGE_SCORE) %>%
  gather(key = "variable", value = "value") %>%
  ggplot(aes(x = value)) +
  geom_histogram(bins = 30, fill = "blue", color = "black", alpha = 0.7) +
  facet_wrap(~variable, scales = "free") +
  theme_minimal()

# Visualizing delinquency
ggplot(df, aes(x = DAYS_PAST_DUE)) +
  geom_histogram(bins = 30, fill = "red", color = "black", alpha = 0.7) +
  theme_minimal() +
  labs(title = "Distribution of Days Past Due")

# Visualizing total revenue by CCS grade
ggplot(df, aes(x = CCS_GRADE, y = TOT_NET_REV, fill = CCS_GRADE)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "Total Revenue by CCS Grade")

# Create a binary variable for delinquency (1 = delinquent, 0 = not delinquent)
df$DELINQUENT <- ifelse(df$DAYS_PAST_DUE > 0, 1, 0)

# Split data into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(df$DELINQUENT, p = 0.7, list = FALSE)
train_data <- df[trainIndex, ]
test_data <- df[-trainIndex, ]

# Logistic regression model
model <- glm(DELINQUENT ~ PAYDEX + FUEL_NET_REV + NONFUEL_NET_REV + TOT_NET_REV + VANTAGE_SCORE + CURRENT_BALANCE + BAL_1_30 + BAL_31_60 + BAL_90_PLUS + CREDIT_LIMIT_x, 
             data = train_data, family = binomial())

# Model summary
summary(model)

# Make predictions on the test set
predictions <- predict(model, test_data, type = "response")
predicted_class <- ifelse(predictions > 0.5, 1, 0)

# Evaluate model performance
confusionMatrix(factor(predicted_class), factor(test_data$DELINQUENT))

# Install necessary package
# install.packages("rpart")

library(rpart)

# Train a decision tree model
tree_model <- rpart(DELINQUENT ~ PAYDEX + FUEL_NET_REV + NONFUEL_NET_REV + TOT_NET_REV + VANTAGE_SCORE + CURRENT_BALANCE + BAL_1_30 + BAL_31_60 + BAL_90_PLUS + CREDIT_LIMIT_x,
                    data = train_data, method = "class")

# Visualize the decision tree
library(rpart.plot)
rpart.plot(tree_model)

# Make predictions on the test set
tree_predictions <- predict(tree_model, test_data, type = "class")

# Evaluate decision tree model performance
confusionMatrix(factor(tree_predictions), factor(test_data$DELINQUENT))

# Create a risk score based on key variables (this can be further refined)
df$RISK_SCORE <- df$DAYS_PAST_DUE * 0.3 + df$BAL_90_PLUS * 0.4 + (850 - df$VANTAGE_SCORE) * 0.3

# Flag risky customers
df$RISK_FLAG <- ifelse(df$RISK_SCORE > 100, "High Risk", "Low Risk")

# Summary of flagged customers
table(df$RISK_FLAG)

